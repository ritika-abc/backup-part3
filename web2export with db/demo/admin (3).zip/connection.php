<?php
$servername = "127.0.0.1:3306";
$username = "u496524825_growindia";
$password = "Aakriti@2022";
$dbname = "u496524825_growindia";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>
